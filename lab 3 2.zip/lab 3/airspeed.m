function [speed,speed_av]= airspeed(VData_P)
    APressure= VData_P(:,1)/1000;
    %Convert to kilo pascal
    R=.287; %kg/kJ*k
    Temp=VData_P(:,2);
    rho=APressure./(R*Temp);
    gage_pressure=abs(VData_P(:,3));
    %Keep in pascals
    speed=sqrt(2*gage_pressure)./(rho);
    speed_av=mean(speed);
end