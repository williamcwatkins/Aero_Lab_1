function [] = AVM (VData_P,VData_V,speed,vspeed)

%% pitot tube plot
Voltage = [VData_P(:,7), ones(45000,1)];

A = Voltage;
B = speed;

X = A \ B;

m = X(1);
b = X(2);

V = linspace(1,9,9);

bestfit = m*V + b;



%% Veturi tube plot

Voltage_2 = [VData_V(:,7), ones(39000,1)];

A2 = Voltage_2;
B2 = vspeed;

X2 = A2 \ B2;

m2 = X2(1);
b2 = X2(2);

bestfit2 = m2*V + b2;



subplot(1,2,1)

hold on;
scatter(VData_V(:,7),B2)
plot(bestfit2)
title('Airspeed Vs. Voltage for Veturi tube')
xlabel('Voltage')
ylabel('Velocity')
hold off;

subplot(1,2,2)

hold on;
scatter(VData_P(:,7),B)
plot(bestfit)
title('Airspeed Vs. Voltage for pitot tube')
xlabel('Voltage')
ylabel('Velocity')
hold off;

end
